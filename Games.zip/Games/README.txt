# open index.html in Mozilla or IE browser.
# for better experence visit http://suryanarayanamurthy.github.io/Games/ 

